package es.iessaladillo.darioojeda.timeapp;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

public class MainActivity extends AppCompatActivity {
    TextView txtFecha;
    TextView txtHora;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        fechaActual();
        horaActual();






    }
    protected void fechaActual() {
        txtFecha = findViewById(R.id.txtFecha);
        Date date = new Date();
        SimpleDateFormat formateo=new SimpleDateFormat("dd/MM/yyyy");
        String fechaFormateada = formateo.format(date);
        txtFecha.setText("Date\n"+fechaFormateada);
    }
    protected void horaActual() {
        txtHora = findViewById(R.id.txtHora);
        Date hour = new Date();
        SimpleDateFormat formateo=new SimpleDateFormat("HH:mm");
        String horaFormateada = formateo.format(hour);
        txtHora.setText("Time\n"+horaFormateada);
    }
}